package com.ictsaeil.demo.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ictsaeil.demo.dto.SaveDto;
import com.ictsaeil.demo.service.ProductService;
import com.ictsaeil.demo.service.UserService;



@Controller
@RequestMapping("/")
public class MainController {
	@Autowired
	MessageSource messageSource;
	@Autowired
	HttpSession session;
	@Autowired
	ProductService productService;
	@Autowired
	UserService userService;
	
	@GetMapping("")
	public ModelAndView main(HttpServletResponse response) throws UnsupportedEncodingException  {
		ModelAndView mv = new ModelAndView("Main");
		//Cookie cookie = new Cookie("message", "from_main"); //기본적으로 공백, 특수문자, 한글 사용 불가
		Cookie cookie = new Cookie("message", URLEncoder.encode("from main", "UTF-8"));
		response.addCookie(cookie);
		
		Integer randomNumber = (Integer)session.getAttribute("random-number");
		if(randomNumber == null) {
			Integer generated = new Random().nextInt();
			System.out.println("generated random number: " + generated.toString());
			session.setAttribute("random-number", generated);
		}
		else {
			System.out.println("my random number : " + randomNumber.toString());
		}
		
		//locale
		Locale.setDefault(Locale.ROOT);
		System.out.println(messageSource.getMessage("name", new String[] {},"name", Locale.getDefault()));
		System.out.println(messageSource.getMessage("name", new String[] {"민지","정민지"},"이름", Locale.KOREA));
		System.out.println(messageSource.getMessage("name", new String[] {},"name", Locale.US));
		System.out.println(messageSource.getMessage("name", new String[] {},"名号", Locale.CHINA));
		System.out.println(messageSource.getMessage("name", new String[] {},"名前", Locale.JAPAN));
		
		Locale currentLocale = LocaleContextHolder.getLocale();
		System.out.println(messageSource.getMessage("name", new String[] {}, "", currentLocale));
	
		return mv;
	}
	
	@GetMapping("product")
	public ModelAndView product () {
		ModelAndView mv = new ModelAndView("Product");
		return mv;
	}
	
	@GetMapping("product/add")
	public String AddProduct() {
		return "AddProduct";
	}
	
	@PostMapping("product/save")
	@ResponseBody
	public boolean requestSave(@RequestBody SaveDto savedto) {
		boolean result = productService.save(savedto);
		return result;
	}
	
	/*@PostMapping("/product/save")
	@ResponseBody
	public boolean saveProduct(@RequestParam String name, @RequestParam int price, @RequestParam int stock) {
		return productService.save(name, price, stock);
	}requestparam으로 구현 */
	
	@GetMapping("/product/remove")
	@ResponseBody
	public boolean removeProduct(@RequestParam String idxListStr) {
		idxListStr = idxListStr.substring(1, idxListStr.length()-2); // [ ]없애기 ex)원래["1","2"]형태--> "1","2
		idxListStr = idxListStr.replace("\"", ""); // "없애기 --> 1,2
		String[] toks = idxListStr.split(","); // , 없애기 --> 1 그리고 2
		List<String> tempList = Arrays.asList(toks); // --> 배열에 담아냄 --> [1,2]
		List<Integer> idxList = new ArrayList<Integer>();
		//json형식을 억지로 배열로 잘라내서 더러운 코드.
		for(String temp : tempList) {
			idxList.add(Integer.parseInt(temp));
		}
		
		return productService.remove(idxList);
	}
	
	@GetMapping("/product/idx")
	@ResponseBody
	public String searchIdx(@RequestParam int idx) {
		Map<String, Object> result = productService.selectIdx(idx);
		return result.toString();
	}
	
	@PostMapping("product/search")
	@ResponseBody
	public Map<String, Object> searchProduct(@RequestParam(required=false)String name){
		Map<String, Object> result = new HashMap<String, Object>();
		
		List<Map<String, Object>> products = null;
		if(name ==null || name.isEmpty()) {
			products = productService.searchByALL();
		} else {
			products = productService.searchByName(name);	
		}
		
		result.put("searchName", name);
		result.put("products", products);
		return result;
	}

	

	@GetMapping("user/{name}/{id}") 
	public ModelAndView user(@PathVariable("name") String name, @PathVariable("id") String id) {
		ModelAndView mv = new ModelAndView("UserNameAndAge");
		
		List<Map<String, Object>> user = userService.searchByNameAndAge(name, id);
			mv.addObject("user",user);
		return mv;
	} //@pathvariable을 이용해서 해보기
	
/*	@GetMapping("user") 
	public ModelAndView user(@RequestParam String name, @RequestParam String id) {
		ModelAndView mv = new ModelAndView("UserNameAndAge");
		
		List<Map<String, Object>> user = userService.searchByNameAndAge(name, id);
		mv.addObject("user",user);
		return mv;
	} */
	
	@GetMapping("my-page") //주소창뒤에올태그
	public String myPage() {
		return "MyPage";
	}
	
	@GetMapping("signin")
	public String signIn() {
		return "Signin";
	}
	@GetMapping("signup")
	public ModelAndView signUp(@CookieValue(value="message", required=false) Cookie cookie)
	throws UnsupportedEncodingException {
		ModelAndView mv = new ModelAndView("Signup");
		
		if(cookie != null) {
			String value = cookie.getValue();
			System.out.println("cookie message: " + URLDecoder.decode(value, "UTF-8"));
		}
		return mv;
	}
	
	@GetMapping("signup/{id}")
	@ResponseBody
	public Map<String, Object> DuplicateCheckId(@PathVariable("id") String id){
		String user = userService.searchOnlyUserId(id);
		Map<String, Object> map = new HashMap<String, Object>();
		
		//service로 옮기기
		if(user!=null) {
			map.put("isDuplicated", true);
		}else {
			map.put("isDuplicated", false);
			map.put("requestId", id);
		}
		
		return map;
	}
	//선생님코드 
	/*@GetMapping("duplication-check/{id}")
	@ResponseBody
	public ResponseEntity duplicationCheckId(@PathVariable("id") String id) {
		try {
			Map<String, Object> body = userService.duplicationCheckId(id);
			return new ResponseEntity<>(body, HttpStatus.OK);
		}catch (Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}*/
	
	@PostMapping("/signup-result")
	public ModelAndView signup_result(){
		ModelAndView mv = new ModelAndView("SignupResult");
		return mv;
	}
	
	

	
}