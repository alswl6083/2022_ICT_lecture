package com.ictsaeil.demo.dto;

public class RequestUserDto {
	private int idx;
	private String id;
	private String password;
	private String name;
	private int age;
	private String email;
	private String mobile;
	
	public int getIdx() {
		return idx;
	}
	public String getId() {
		return id;
	}
	public String getPassword() {
		return password;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getEmail() {
		return email;
	}
	public String getMobile() {
		return mobile;
	}
	
	public void setIdx(int idx) {
		this.idx= idx;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setName(String name) {
		this.name= name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public void setEmail(String email) {
		this.email=email;
	}
	public void setMobile(String mobile) {
		this.mobile=mobile;
	}
}
