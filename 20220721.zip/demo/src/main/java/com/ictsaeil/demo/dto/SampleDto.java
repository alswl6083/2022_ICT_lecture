package com.ictsaeil.demo.dto;

public class SampleDto {
	private String stringData;
	private int intData;
	
	public String getStringData() {
		return stringData;
	}
	public void setStringData(String stringData) {
		this.stringData = stringData;
	}
	public int getIntData() {
		return intData;
	}
	public void setIntData(int intData) {
		this.intData = intData;
	}
}
