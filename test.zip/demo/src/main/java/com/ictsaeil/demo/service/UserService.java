package com.ictsaeil.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ictsaeil.demo.dao.UserDAO;

@Service
public class UserService {
	@Autowired
	UserDAO userDao;

	
	public List<Map<String, Object>> searchByNameAndAge(String name, String id){
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("NAME", name);
		paramMap.put("ID", id);
		
		List<Map<String, Object>> resultMap = userDao.selectByNameAndAge(paramMap);
		return resultMap;
	}
	
	public List<Map<String, Object>> searchUserCount(){
		
		List<Map<String,Object>> resultMap= userDao.selectUserCount();
		return resultMap;
	}
	
	public List<Map<String, Object>> searchUser(){
		List<Map<String, Object>> resultMap =  userDao.selectUserList();
		
		return resultMap;
	}
	
	public List<Map<String,Object>>searchUserId(String id){
		
		List<Map<String,Object>> resultMap = userDao.selectUserId(id);
		
		return resultMap;
	}
	
	public List<Map<String, Object>>searchUserName(String name){
		List<Map<String, Object>> resultMap = userDao.selectUserName(name);
		
		return resultMap;
	}
	public List<Map<String, Object>>updateUserIDtoName(String id){
		List<Map<String, Object>> resultMap = userDao.updateUserIDtoName(id);
		
		return resultMap;
	}

	
}
