package com.ictsaeil.demo.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
//DAO
@Mapper
public interface UserDAO {
	
		public List<Map <String, Object>> selectByNameAndAge(Map<String, Object> paramMap);
		public List<Map<String, Object>> selectUserCount();
		public List<Map<String, Object>> selectUserList();
		public List<Map<String, Object>> selectUserId(String id);
		public List<Map<String, Object>> selectUserName(String name);
		public List<Map<String, Object>>updateUserIDtoName(String id);
}
