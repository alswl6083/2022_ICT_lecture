package com.ictsaeil.demo.service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ictsaeil.demo.dao.ProductMapper;

@Service
public class ProductService {
	@Autowired
	ProductMapper productMapper;
	
	public List<Map<String, Object>> searchByALL(String name){
		
		
		List<Map<String,Object>> resultMap = productMapper.selectByALL();
		
		for(Map<String, Object> product : resultMap) {
			int stock1 = (int)product.get("STOCK");
			
			String status = "";
			if(stock1 > 0 && stock1 <=100) {
				status = "품절임박";
			}
			else if(stock1 == 0 ) {
				status = "품절";
			}
			product.put("STATUS", status);
		}
		return resultMap;
	}
}
