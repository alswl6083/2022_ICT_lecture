package com.ictsaeil.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ictsaeil.demo.dto.RequestUserDto;
import com.ictsaeil.demo.service.UserService;


@RestController
@RequestMapping("/api")
public class ApiController{
	@Autowired
	UserService userService;

	
	@GetMapping("users")
	public ResponseEntity getUsers() {
	System.out.println("GET /api/users");
	
	//요청 성공
	List<Map<String, Object>> body = userService.searchUser();
	HttpStatus status = HttpStatus.OK;
	
	
	return new ResponseEntity<>(body, status);
	}
	
	@GetMapping("users/count")
	public ResponseEntity getUsersCount(){
		System.out.println("GET /api/users/count");
		
		int body = userService.searchUserCount();
		HttpStatus status = HttpStatus.OK;
		
		return new ResponseEntity<>(body, status);
	}
	
	@GetMapping("users/{id}")
	public ResponseEntity getUserId(@PathVariable("id") String id) {
		System.out.println("GET /api/users/{id}, id=" + id);
		
		Map<String, Object> body = userService.searchUserId(id);
		HttpStatus status = HttpStatus.OK;
		
		return new ResponseEntity<>(body, status);
	}
	
	@GetMapping("users/{id}/cart-items")
	public void getUserCartItems(@PathVariable("id") String id) {
		System.out.println("GET /api/users/{id}/cart-items, id="+ id);
	}
	
	@GetMapping("user")
	public ResponseEntity getUser(@RequestParam String name) {
		System.out.println("GET /api/user?name="+name);
		
		List<Map<String, Object>> body = userService.searchUserName(name);
		HttpStatus status = HttpStatus.OK;
		
		return new ResponseEntity<>(body, status);
	}
	
	
	@PutMapping("users/{id}")
	public ResponseEntity getUser(@PathVariable("id") String id, @RequestBody RequestUserDto request) {
		System.out.println("PUT /api/users/{id}, id=" +id+", set name="+ request.getName());
		
		boolean result = userService.updateUserIDtoName(id, request);
		
		HttpStatus status = HttpStatus.OK;
		if(!result) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<>(status);
	}
	
	@DeleteMapping("users/{id}")
	public ResponseEntity deleteUser(@PathVariable("id") String id){
		System.out.println("DELETE /api/users{id}, id="+ id);
		
		boolean result = userService.delete(id);
		
		HttpStatus status = HttpStatus.OK;
		if(!result) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<>(status);
	}
	
	@PostMapping("user")
	public ResponseEntity createUser(@RequestBody RequestUserDto request){
		System.out.println("POST /api/user, name=" + request.getName());
		
		boolean result = userService.insert(request);
		
		HttpStatus status = HttpStatus.OK;
		if(!result) {
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<>(status);
	}
}
