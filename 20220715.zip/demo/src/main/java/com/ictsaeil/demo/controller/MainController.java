package com.ictsaeil.demo.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ictsaeil.demo.service.ProductService;
import com.ictsaeil.demo.service.UserService;



@Controller
@RequestMapping("/")
public class MainController {
	@Autowired
	MessageSource messageSource;
	@Autowired
	HttpSession session;
	@Autowired
	ProductService productService;
	@Autowired
	UserService userService;
	
	@GetMapping("")
	public ModelAndView main(HttpServletResponse response) throws UnsupportedEncodingException  {
		ModelAndView mv = new ModelAndView("Main");
		//Cookie cookie = new Cookie("message", "from_main"); //기본적으로 공백, 특수문자, 한글 사용 불가
		Cookie cookie = new Cookie("message", URLEncoder.encode("from main", "UTF-8"));
		response.addCookie(cookie);
		
		Integer randomNumber = (Integer)session.getAttribute("random-number");
		if(randomNumber == null) {
			Integer generated = new Random().nextInt();
			System.out.println("generated random number: " + generated.toString());
			session.setAttribute("random-number", generated);
		}
		else {
			System.out.println("my random number : " + randomNumber.toString());
		}
		
		//locale
		Locale.setDefault(Locale.ROOT);
		System.out.println(messageSource.getMessage("name", new String[] {},"name", Locale.getDefault()));
		System.out.println(messageSource.getMessage("name", new String[] {"민지","정민지"},"이름", Locale.KOREA));
		System.out.println(messageSource.getMessage("name", new String[] {},"name", Locale.US));
		System.out.println(messageSource.getMessage("name", new String[] {},"名号", Locale.CHINA));
		System.out.println(messageSource.getMessage("name", new String[] {},"名前", Locale.JAPAN));
		
		Locale currentLocale = LocaleContextHolder.getLocale();
		System.out.println(messageSource.getMessage("name", new String[] {}, "", currentLocale));
	
		return mv;
	}
	
	@GetMapping("product")
	public ModelAndView product () {
		ModelAndView mv = new ModelAndView("Product");
		
		System.out.println("MainController: before productService.search");
		List<Map<String, Object>> product = productService.searchByALL();
		System.out.println("MainController: after productService.search");
		
		mv.addObject("product",product);
		return mv;
	}

	

	@GetMapping("user/{name}/{id}") 
	public ModelAndView user(@PathVariable("name") String name, @PathVariable("id") String id) {
		ModelAndView mv = new ModelAndView("UserNameAndAge");
		
		List<Map<String, Object>> user = userService.searchByNameAndAge(name, id);
			mv.addObject("user",user);
		return mv;
	} //@pathvariable을 이용해서 해보기
	
/*	@GetMapping("user") 
	public ModelAndView user(@RequestParam String name, @RequestParam String id) {
		ModelAndView mv = new ModelAndView("UserNameAndAge");
		
		List<Map<String, Object>> user = userService.searchByNameAndAge(name, id);
		mv.addObject("user",user);
		return mv;
	} */
	
	@GetMapping("my-page") //주소창뒤에올태그
	public String myPage() {
		return "MyPage";
	}
	
	@GetMapping("signin")
	public String signIn() {
		return "Signin";
	}
	@GetMapping("signup")
	public ModelAndView signUp(@CookieValue(value="message", required=false) Cookie cookie)
	throws UnsupportedEncodingException {
		ModelAndView mv = new ModelAndView("Signup");
		
		if(cookie != null) {
			String value = cookie.getValue();
			System.out.println("cookie message: " + URLDecoder.decode(value, "UTF-8"));
		}
		return mv;
	}
	

	
}