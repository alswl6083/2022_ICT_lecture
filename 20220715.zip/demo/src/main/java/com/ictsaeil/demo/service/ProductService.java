package com.ictsaeil.demo.service;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ictsaeil.demo.dao.ProductMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class ProductService {
	private Logger logger = LogManager.getLogger(ProductService.class);
	@Autowired
	ProductMapper productMapper;
	
	public List<Map<String, Object>> searchByALL(){
		
		
		List<Map<String,Object>> resultMap = productMapper.selectByALL();
		
		for(Map<String, Object> product : resultMap) {
			int stock1 = (int)product.get("STOCK");
			
			String status = "";
			if(stock1 > 0 && stock1 <=100) {
				status = "품절임박";
			}
			else if(stock1 == 0 ) {
				status = "품절";
			}
			product.put("STATUS", status);
		}
		
		logger.fatal("[FATAL]");
		logger.error("[ERROR]");
		logger.warn("[WARN]");
		logger.info("[INFO]");
		logger.debug("[DEBUG]");
		logger.trace("[TRACE]");
		
		return resultMap;
	}
}
