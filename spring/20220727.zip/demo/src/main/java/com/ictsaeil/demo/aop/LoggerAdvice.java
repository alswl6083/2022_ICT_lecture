package com.ictsaeil.demo.aop;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


@Component
@Aspect
public class LoggerAdvice {
	
	@Before("execution(* com.ictsaeil.demo.service.ProductService*.*(..))")
	public void startLog(JoinPoint joinPoint) {
		System.out.println("start log");
		System.out.println("start log: " + joinPoint.getSignature());
		System.out.println("start log: " + Arrays.toString(joinPoint.getArgs()));
	}
}
