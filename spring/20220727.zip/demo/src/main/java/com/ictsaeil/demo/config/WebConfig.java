package com.ictsaeil.demo.config;

import java.util.List;
import java.util.Locale;
import java.util.Arrays;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import com.ictsaeil.demo.filter.FirstFilter;
import com.ictsaeil.demo.filter.SecondFilter;
import com.ictsaeil.demo.interceptor.PageInterceptor;


@Configuration
public class WebConfig implements WebMvcConfigurer {
	private static final List<String> PATH_PATTERNS = Arrays.asList("/*");
	private static final List<String> EX_PATH_PATTERNS = Arrays.asList("/api/*");
	
	
	//인터셉터
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new PageInterceptor())
			.addPathPatterns(PATH_PATTERNS)
			.excludePathPatterns(EX_PATH_PATTERNS);
		
		registry.addInterceptor(localeChangeInterceptor()); //locale
		
		WebMvcConfigurer.super.addInterceptors(registry);
	}
	
	//필터
	@Bean
	public FilterRegistrationBean<FirstFilter> firstFilterRegistarationBean(){
		FilterRegistrationBean<FirstFilter> filterRegistrationBean
		 = new FilterRegistrationBean<FirstFilter>(new FirstFilter());
		filterRegistrationBean.setOrder(1);
		filterRegistrationBean.setUrlPatterns(EX_PATH_PATTERNS);
		
		return filterRegistrationBean;
	}
	
	@Bean
	public FilterRegistrationBean<SecondFilter> secondFilterRegistarationBean(){
		FilterRegistrationBean<SecondFilter> filterRegistrationBean
		 = new FilterRegistrationBean<SecondFilter>(new SecondFilter());
		filterRegistrationBean.setOrder(2);
		filterRegistrationBean.setUrlPatterns(EX_PATH_PATTERNS);
		
		return filterRegistrationBean;
	}
	
	//다국어처리
	@Bean
	public CookieLocaleResolver localeResolver() {
		CookieLocaleResolver localeResolver = new CookieLocaleResolver();
		localeResolver.setDefaultLocale(Locale.CHINA); //최초의 기본 Locale 설정
		localeResolver.setCookieName("locale"); //쿠키 key 설정
		return localeResolver;
	}
	
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		localeChangeInterceptor.setParamName("locale");//URL파라미터로 받을 이름
		return localeChangeInterceptor;
		
	}
	
	
	


}
