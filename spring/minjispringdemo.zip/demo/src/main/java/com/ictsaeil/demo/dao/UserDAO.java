package com.ictsaeil.demo.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
//DAO
@Mapper
public interface UserDAO {
	
		public List<Map <String, Object>> selectByNameAndAge(Map<String, Object> paramMap);
		public int selectUserCount();
		public List<Map<String, Object>> selectUserList();
		public Map<String, Object> selectUserId(String id);
		public List<Map<String, Object>> selectUserName(String name);
		public int updateUserIDtoName(Map<String, Object>paramMap);
		public int insert(Map<String, Object>paramMap);
		public int delete(String id);
		public String selectOnlyUserId(String id);
}
