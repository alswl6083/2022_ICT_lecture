package com.ictsaeil.demo.service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ictsaeil.demo.dao.ProductDao;
import com.ictsaeil.demo.dto.DetailDto;
import com.ictsaeil.demo.dto.SaveDto;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class ProductService {
	private Logger logger = LogManager.getLogger(ProductService.class);
	@Autowired
	ProductDao productDao;
	
	public List<Map<String, Object>> searchByALL(){
		
		
		List<Map<String,Object>> resultMap = productDao.selectByALL();
		
		for(Map<String, Object> product : resultMap) {
			int stock1 = (int)product.get("STOCK");
			
			String status = "";
			if(stock1 > 0 && stock1 <=100) {
				status = "품절임박";
			}
			else if(stock1 == 0 ) {
				status = "품절";
			}
			product.put("STATUS", status);
		}
		
		logger.fatal("[FATAL]");
		logger.error("[ERROR]");
		logger.warn("[WARN]");
		logger.info("[INFO]");
		logger.debug("[DEBUG]");
		logger.trace("[TRACE]");
		
		return resultMap;
	}
	


public List<Map<String, Object>> searchByName(String name) {
	List<Map<String, Object>> products = productDao.selectByName(name);
	
	for(Map<String, Object> product : products) {
		int stock = (int)product.get("STOCK");
		
		String status = "";
		if(stock > 0 && stock <= 100) {
			status = "품절임박";
		} else if(stock == 0) {
			status = "품절";
		}
		
		product.put("STATUS", status);
	}
	
	return products;
	}

public boolean save(SaveDto save) {
	Map<String, Object>paramMap = new HashMap<>();
	
	paramMap.put("NAME", save.getName());
	paramMap.put("PRICE", save.getPrice());
	paramMap.put("STOCK", save.getStock());
	
	int result = productDao.insertsave(paramMap);
	if(result>0) return true;
	else return false;
}



public boolean remove(List<Integer> idxList) {
	Map<String, Object> paramMap = new HashMap<String, Object>();
	paramMap.put("IDX_LIST", idxList);
	
	if(productDao.delete(paramMap) > 0) {
		return true;
	} else {
		return false;
	}
}

public Map<String, Object> selectIdx(int idx) {
	
	return productDao.selectByIdx(idx);
}

/*public int insertcart(int user_idx, int product_idx){
	
	return productDao.insertcart(user_idx,product_idx);
}*/

public int insertcart(DetailDto data){
	Map<String, Object> paramMap = new HashMap<String, Object>();
	paramMap.put("USER_IDX", data.getUser_idx());
	paramMap.put("PRODUCT_IDX", data.getProduct_idx());
	return productDao.insertcart(paramMap);
}

public List<Map<String, Object>> selectMyJoin(int idx){
	
	return productDao.selectMyJoin(idx);
	
}

}
