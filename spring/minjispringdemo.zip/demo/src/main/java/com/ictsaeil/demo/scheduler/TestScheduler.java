package com.ictsaeil.demo.scheduler;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TestScheduler {

	//@Scheduled(fixedDelay = 5000)
	public void task1() {
		System.out.println("["+LocalDateTime.now()+"] [task1]");
	}
	//application.properties
	//@Scheduled(fixedDelayString= "${testscheduler.fixed.delay}")
	public void task2() {
		System.out.println("["+LocalDateTime.now()+"] [task2]");
	}
	
	
	//@Scheduled(fixedRate=5000)
	public void task3() {
		System.out.println("["+LocalDateTime.now()+"] [task3]");
	}
	//application.properties
	//@Scheduled(fixedRateString="${testscheduler.fixed.rate}")
	public void task4() {
		System.out.println("["+LocalDateTime.now()+"] [task4]");
	}
	//5초 뒤에 5초마다 실행
	//@Scheduled(fixedDelay=5000, initialDelay = 5000)
	public void task5() {
		System.out.println("[" + LocalDateTime.now()+"] [task5]");
	}
	
	//@Scheduled(cron= "00 15 * * * *")
	public void task7() {
		System.out.println("[" + LocalDateTime.now()+"] [task6]");
	}
	
	//뉴욕시간으로 설정
	//@Scheduled(cron="00 21 * * * *", zone = "America/New_York")
	public void task8() {
		TimeZone tz=TimeZone.getTimeZone("America/New_York");
		Date data = new Date();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		df.setTimeZone(tz);
		
		System.out.println("["+ df.format(data)+ "] [task7]");
	}
	
	
	//@Scheduled(fixedDelay = 1000)
	public void task9() {
		System.out.println("["+ LocalDateTime.now()+"] [task9]" + Thread.currentThread().getName());
		try {
			for(int i=0; i<10; i++) {
				Thread.sleep(1000);
				System.out.println("["+ LocalDateTime.now()+"][task9] working...");
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//@Scheduled(fixedDelay = 1000)
	public void task10() {
		System.out.println("["+ LocalDateTime.now()+"] [task10]" + Thread.currentThread().getName());
		try {
			for(int i=0; i<10; i++) {
				Thread.sleep(1000);
				System.out.println("["+ LocalDateTime.now()+"][task10] working...");
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//@Scheduled(fixedDelay = 5000)
	//@Async
	public void task11() {
		System.out.println("["+ LocalDateTime.now()+"] [task11]" + Thread.currentThread().getName());
		try {
			for(int i=0; i<10; i++) {
				Thread.sleep(1000);
				System.out.println("["+ LocalDateTime.now()+"][task11] working...");
			}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	

}
