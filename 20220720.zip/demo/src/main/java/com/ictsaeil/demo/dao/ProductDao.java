package com.ictsaeil.demo.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ProductDao {
	public List<Map<String, Object>>selectByALL();
	public List<Map<String, Object>> selectByName(String name);
	public int insertsave(Map<String, Object>paramMap); //mapper호출
	public int delete(Map<String, Object> paramMap);
	public Map<String, Object> selectByIdx(int idx);
}
