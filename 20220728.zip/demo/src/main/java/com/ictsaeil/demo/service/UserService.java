package com.ictsaeil.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ictsaeil.demo.dao.UserDAO;
import com.ictsaeil.demo.dto.RequestUserDto;

@Service
public class UserService {
	@Autowired
	UserDAO userDao;

	
	public List<Map<String, Object>> searchByNameAndAge(String name, String id){
		Map<String,Object> paramMap = new HashMap<String, Object>();
		paramMap.put("NAME", name);
		paramMap.put("ID", id);
		
		List<Map<String, Object>> resultMap = userDao.selectByNameAndAge(paramMap);
		return resultMap;
	}
	
	public int searchUserCount(){
		
		int resultMap= userDao.selectUserCount();
		return resultMap;
	}
	
	public List<Map<String, Object>> searchUser(){
		List<Map<String, Object>> resultMap =  userDao.selectUserList();
		
		return resultMap;
	}
	
	public Map<String,Object>searchUserId(String id){
		
		Map<String, Object> resultMap = userDao.selectUserId(id);
		
		return resultMap;
	}
	
	public List<Map<String, Object>>searchUserName(String name){
		List<Map<String, Object>> resultMap = userDao.selectUserName(name);
		
		return resultMap;
	}
	public boolean updateUserIDtoName(String id, RequestUserDto user){
		Map<String, Object> paramMap = new HashMap<>();
		
		paramMap.put("PASSWORD", user.getPassword());
		paramMap.put("NAME", user.getName());
		paramMap.put("AGE", user.getAge());
		paramMap.put("EMAIL", user.getEmail());
		paramMap.put("MOBILE", user.getMobile());
		paramMap.put("ID", id);
		
		int result = userDao.updateUserIDtoName(paramMap);
		//원래 int인데 바뀐 행 갯수보다 update가 잘됐는지 유무를 보기위해 boolean으로 변경.
		if(result>0) return true;
		else return false;
		
	}
	public boolean insert(RequestUserDto user) {
		Map<String, Object>paramMap = new HashMap<>();
		
		paramMap.put("ID", user.getId());
		paramMap.put("PASSWORD", user.getPassword());
		paramMap.put("NAME", user.getName());
		paramMap.put("AGE", user.getAge());
		paramMap.put("EMAIL", user.getEmail());
		paramMap.put("MOBILE", user.getMobile());
		
		int result = userDao.insert(paramMap);
		
		if(result>0) return true;
		else return false;
		
	}
	
	public boolean delete(String id) {
		int result = userDao.delete(id);
		
		if(result>0) return true;
		else return false;
	}

	
}
